﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankRequestProblem
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] balances = { 700, 1000 }; //initializing balances
            //initializing requests. 1649163862 represents 4/5/2022, 9:04:22 AM, 1649250262 represents 4/6/2022, 9:04:22 AM & 1649423062 represents 4/8/2022, 9:04:22 AM
            String[] requests = { "withdraw 1649163862 2 500", "withdraw 1649250262 2 510", "deposit 1649423062 1 150" };
            //calling method and store result in array.
            int[] calculatedbal = solution(balances, requests);
            //using inbuild array for each method to print contents in array
            Array.ForEach(calculatedbal, Console.WriteLine);

        }

        public static int[] solution(int[] balances, String[] requests)
        {

            Queue<long> timestamps = new Queue<long>(); //creating queue to hold timestamp for cash request
            Queue<int> holders = new Queue<int>(); //creating queue to hold holder id for cash request
            Queue<int> amounts = new Queue<int>(); //creating queue to hold amounts for cash request

            //iterate to run loop for each request received in input request 
            for (int i = 0; i < requests.Length; i++)
            {
                
                string request = requests[i]; //variable hold single request
                string[] args = request.Split(' '); //split input request

                //Run while loop until timestamps queue is not empty
                while (timestamps.Count != 0)
                {
                    /*peek (retrieve) first item (timestamp of first request + 86400 seconds (24 hours)) in queue and compare the timestamp for next transaction
                      if next transaction after occured after 24 hours then remove the first cash back entry from queues and add the cash back to the corrresponding 
                      account. It will check for all the cash back transaction pending in queue to adjust so while loop will be executed until queue is empty.
                    */
                    if (timestamps.Peek() <= long.Parse(args[1]))
                    {
                        
                        timestamps.Dequeue();
                        balances[holders.Dequeue() - 1] += amounts.Dequeue();
                    }
                    else
                        break;
                }

                long reqtimestamp = long.Parse(args[1]); //variable holds timestamp receiving in request
                int holderId = int.Parse(args[2]); //variable holds holder id receiving in request
                int amount = int.Parse(args[3]); //variable holds amount receiving in request

                // if holdder Id is less then 1 OR holder id is greater than the balances provided for holder ids then return 
                if (holderId < 1 || holderId > balances.Length)
                {
                    return new int[0] ;
                }

                // check if request is for withdraw or deposit
                if (args[0].Equals("withdraw"))
                {
                    // check if the balance 
                    if (balances[holderId - 1] < amount)
                    {
                        return new int[0];
                    }
                    else
                    {
                        //add amount to balance. -1 is used since index is started with 0 but the holder id was provided with number greater than 0
                        balances[holderId - 1] -= amount; 
                        timestamps.Enqueue(reqtimestamp + 86400); //add timestamp + 86400 to check 24 hours
                        holders.Enqueue(holderId); //add holder id in queue
                        amounts.Enqueue((int)(amount * 0.02)); //add cash back amount in queue
                    }
                }
                else
                {
                    balances[holderId - 1] += amount; //deposit the amount to balances
                }

            }
            return balances;  //return total balances

        }
    }
}
